//
//  BogoArtistAppTests.swift
//  BogoArtistAppTests
//
//  Created by TheAppSmiths on 1/2/18.
//  Copyright © 2018 TheAppSmiths. All rights reserved.
//

import XCTest
@testable import BogoArtistApp
//import HCSStarRatingView

class BogoArtistAppTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
//MARK:- ==================>Login Validation Cases<=====================
    func testTrimLeftPaddingLoginFirstNameValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        objVC.obj.firstName = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.firstName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "First name cannot have whitespaces")
    }
    func testTrimLeftPaddingLoginLastNameValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        objVC.obj.lastName = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.lastName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "First name cannot have whitespaces")
    }
    func testTrimRightPaddingLoginFirstNameValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        objVC.obj.firstName = "aaaaa "
        let whiteSpaceRange: NSRange = (objVC.obj.firstName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "First name cannot have whitespaces")
    }
    func testTrimRightPaddingLoginLastNameValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        objVC.obj.lastName = "aaaaa "
        let whiteSpaceRange: NSRange = (objVC.obj.lastName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "First name cannot have whitespaces")
    }
    func testTrimRightPaddingLoginEmailValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        objVC.obj.email = "aaaaa "
        let whiteSpaceRange: NSRange = (objVC.obj.email as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Email cannot have whitespaces")
    }
    func testEmptyFieldValidation() {
       
         let ObjVC = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        XCTAssertTrue(ObjVC.obj.email.length == 0, "Text field should not be empty.")
    }
    
    func testTextFieldMaxlengthValidation() {
       let ObjVC = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        XCTAssertTrue((ObjVC.obj.email.length) <= 100, "Text field length should not be more than 100 characters")
    }
    
    func testPasswordMinlengthValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        
        XCTAssertTrue((vc.obj.password.trimWhiteSpace.length < passwordMinLength), "Text field password should not less than 8 characters")
    }
    
    func testEmptyPasswordValidation()  {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        XCTAssertTrue((vc.obj.password.trimWhiteSpace.length == 0), "Text field should not be empty")
    }
    
    
    func testValidEmail() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        XCTAssertTrue(!(vc.obj.email.isEmail) , "Email is not valid")
    }
    
    func testTrimLeftPaddingLoginEmailValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGLoginVC") as! BGLoginVC
        objVC.obj.email = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.email as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Email cannot have whitespaces")
    }
    
    //MARK:- =====================>Signup Validation Cases<=======================
    func testTrimLeftPaddingRegisterFirstNameValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        objVC.obj.firstName = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.firstName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "First name cannot have whitespaces")
    }
    func testTrimLeftPaddingRegisterLastNameValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        objVC.obj.lastName = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.lastName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "First name cannot have whitespaces")
    }
    func testTrimRightPaddingRegisterEmailValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        objVC.obj.email = "aaaaa "
        let whiteSpaceRange: NSRange = (objVC.obj.email as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Email cannot have whitespaces")
    }
    func testTrimLeftPaddingRegisterEmailValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        objVC.obj.email = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.email as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Email cannot have whitespaces")
    }
    func testFirstNameEmptyValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue((vc.obj.firstName.trimWhiteSpace.length == empty) , "First name text field should not be empty.")
    }
    func testFirstNameMinLengthValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue((vc.obj.firstName.trimWhiteSpace.length < nameMinLength) , "First name text field should not be less than 2 characters.")
    }
    func testValidFirstNameValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue(!(vc.obj.firstName.isValidName) , "First name is not valid")
    }
    func testLastNameEmptyValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue((vc.obj.lastName.trimWhiteSpace.length == empty) , "Last name text field should not be empty.")
    }
    
    func testLastNameMinLengthValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue((vc.obj.lastName.trimWhiteSpace.length < nameMinLength), "Last name text field should not be less than 2 characters.")
    }
    
    func testValidLastNameValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue(!(vc.obj.lastName.isValidName) , "Last name is not valid")
    }
    func testAlphaNumericLastNameValidation() {
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue(!(vc.obj.lastName.containsAlphabetsOnly()) , "Last name is not valid")
    }
    
    func testEmptySignUpEmailValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        XCTAssertTrue((vc.obj.email.trimWhiteSpace.length == empty) , "Email textfiled should not be empty.")
    }
    
    func testSignUpEmailValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        //Test TextField should not be empty
        XCTAssertTrue(!(vc.obj.email.isEmail) , "Email is not valid.")
    }
    
    func testEmptySignupPasswordValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        //Test TextField should not be empty obj.password.trimWhiteSpace.length < passwordMinLength
        XCTAssertTrue((vc.obj.password.trimWhiteSpace.length == empty) , "password textfiled should not be empty.")
    }
    
    func testSignupPasswordMinLengthValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue((vc.obj.password.trimWhiteSpace.length < passwordMinLength) , "password textfiled should not be less than 6 characters.")
    }
    
    func testEmptySignupConfirmPasswordValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        //Test TextField should not be empty
        XCTAssertTrue((vc.obj.confirmPassword.trimWhiteSpace.length == empty) , "Confirm password textfiled should not be empty.")
    }
    
    func testSignupConfirmPasswordMinLengthValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGRegisterVC") as! BGRegisterVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue((vc.obj.confirmPassword.trimWhiteSpace.length < passwordMinLength) , "Confirm password textfiled should not be less than 6 characters.")
    }
    
    //MARK:- =====================>Forget Password Validation Cases<=======================

    func testTrimRightPaddingForgotPasswordEmailValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGForgotPasswordVC") as! BGForgotPasswordVC
        objVC.obj.email = "aaaaa "
        let whiteSpaceRange: NSRange = (objVC.obj.email as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Email cannot have whitespaces")
    }
    func testForgotsswordEmailMinLengthValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGForgotPasswordVC") as! BGForgotPasswordVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue((vc.obj.email.trimWhiteSpace.length < passwordMinLength) , "Email should not be less than 6 characters.")
    }
    func testForgotsswordEmailEmptyValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGForgotPasswordVC") as! BGForgotPasswordVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue((vc.obj.email.trimWhiteSpace.length == 0) , "Email textfiled should not be empty.")
    }
    func testTrimLeftPaddingPorgotPasswordEmailValidation() {
        let objVC = UIStoryboard(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGForgotPasswordVC") as! BGForgotPasswordVC
        objVC.obj.email = " aaaaa"
        let whiteSpaceRange: NSRange = (objVC.obj.email as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Email cannot have whitespaces")
    }
    func testForgotsswordEmailValidation(){
        let vc = UIStoryboard.init(name: "Auth", bundle:nil).instantiateViewController(withIdentifier: "BGForgotPasswordVC") as! BGForgotPasswordVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue(!(vc.obj.email.isEmail) , " Email is not valid")
    }
    
    //MARK:- =====================>Edit Profile Validation Cases<=======================obj.profileName.trimWhiteSpace.length == empty
    
    func testTrimRightPaddingStylistNameValidation() {
        let objVC = UIStoryboard(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGProfileVC") as! BGProfileVC
        objVC.obj.profileName = "aaaaa "
        let whiteSpaceRange: NSRange = (objVC.obj.profileName as NSString).rangeOfCharacter(from: CharacterSet.whitespaces)
        XCTAssertNotEqual(whiteSpaceRange.location, NSNotFound, "Name cannot have whitespaces")
    }
    func testProfileNameEmptyValidation(){
        let vc = UIStoryboard.init(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGProfileVC") as! BGProfileVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue( vc.obj.profileName.trimWhiteSpace.length == 0 , "Profile name should not empty")
    }
    
    func testProfileNameMinLengthValidation(){
        let vc = UIStoryboard.init(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGProfileVC") as! BGProfileVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue( vc.obj.profileName.trimWhiteSpace.length < 4 , "Profile name should not  be less than 4 charchters")
    }

    func testProfileNameMaxLengthValidation(){
        let vc = UIStoryboard.init(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGProfileVC") as! BGProfileVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue( !(vc.obj.profileName.trimWhiteSpace.length > 32) , "Profile name should not  be more than 32 charchters")
    }
    
    func testProfileNameContainStringValidation(){
        let vc = UIStoryboard.init(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGProfileVC") as! BGProfileVC
        //Test TextField should not be empty obj.confirmPassword.trimWhiteSpace.length == empty
        XCTAssertTrue(!(vc.obj.profileName.containsAlphabetsOnly()) , " Profile name is not valid")
    }
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}
