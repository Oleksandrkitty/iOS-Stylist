//
//  ButtonExtension.swift
//  ProjectTemplate
//
//  Created by TheAppSmiths on 01/06/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

extension UIButton {

    func underLine(state: UIControlState = .normal) {
        
        if let title = self.title(for: state) {
            
            let color = self.titleColor(for: state)

            let attrs = [NSAttributedStringKey.foregroundColor.rawValue : color ?? UIColor.blue,
                NSAttributedStringKey.underlineStyle : 1] as! [NSAttributedStringKey : Any]
            
            let buttonTitleStr = NSMutableAttributedString(string:title, attributes:attrs)
            self.setAttributedTitle(buttonTitleStr, for: state)
        }
    }

}

