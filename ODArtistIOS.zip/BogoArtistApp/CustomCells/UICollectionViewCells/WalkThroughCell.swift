//
//  WalkThroughCell.swift
//  eKinCare
//
//  Created by TheAppSmiths on 21/07/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class WalkThroughCell: UICollectionViewCell {
    
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var collectionImageView: UIImageView!

}
