//
//  BGWalkThroughCell2.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 28/12/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class BGWalkThroughCell2: UICollectionViewCell {
    @IBOutlet var verticalAlignmentConstant: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        if kWindowWidth == 320 {
            verticalAlignmentConstant.constant = 40
        }
    }
}
