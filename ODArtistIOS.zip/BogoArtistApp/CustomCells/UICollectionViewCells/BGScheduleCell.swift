//
//  BGScheduleCell.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 12/28/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class BGScheduleCell: UICollectionViewCell {
    @IBOutlet var timeContainerView: UIView!
    @IBOutlet var timeImageView: UIImageView!
    @IBOutlet var TimeLabel: UILabel!
    @IBOutlet weak var timeSlotLabel: UILabel!
    
}
