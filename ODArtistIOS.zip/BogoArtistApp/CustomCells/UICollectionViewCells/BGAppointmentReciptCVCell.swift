//
//  BGAppointmentReciptCVCell.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 28/12/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class BGAppointmentReciptCVCell: UICollectionViewCell {
    
    @IBOutlet weak var tipView: UIView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var percentLabel: UILabel!
}
