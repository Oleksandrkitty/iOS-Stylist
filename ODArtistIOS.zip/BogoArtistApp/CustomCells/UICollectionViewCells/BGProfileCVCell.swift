//
//  BGProfileCVCell.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 27/12/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class BGProfileCVCell: UICollectionViewCell {
    @IBOutlet weak var crossButton: UIButton!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var collectionImageView: UIImageView!
}
