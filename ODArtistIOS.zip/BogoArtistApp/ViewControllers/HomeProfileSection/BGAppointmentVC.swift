//
//  BGAppointmentVC.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 12/28/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit
import CoreLocation

class BGAppointmentVC: UIViewController,UIActionSheetDelegate {
    
    @IBOutlet weak var contactBtn                   : UIButton!
    @IBOutlet weak var startBookingBtn              : UIButton!
    @IBOutlet weak var BackGroundView               : UIView!
    @IBOutlet weak var cancelBookingBtn             : UIButton!
    @IBOutlet var clientImageView                   : UIImageView!
    @IBOutlet weak var locationView                 : UIView!
    @IBOutlet weak var detailview                   : UIView!
    @IBOutlet weak var tableView                    : UITableView!
    @IBOutlet weak var Arrow2Image                  : UIImageView!
    @IBOutlet weak var detailsTexTView              : UITextView!
    @IBOutlet weak var completeBookingTopConstraint : NSLayoutConstraint!
    @IBOutlet weak var clientName                   : UILabel!
    @IBOutlet weak var arrow3Constraint             : NSLayoutConstraint!
    @IBOutlet weak var clientTime                   : UILabel!
    @IBOutlet weak var clientLocation               : UILabel!
    @IBOutlet weak var moreImageView                : UIImageView!
    @IBOutlet var clientDescription                 : UITextView!
    @IBOutlet weak var arrow3Image                  : UIImageView!
    var upcommingInfo                               = BGUpcomingInfoModel()
    var upcommingList                               = [Dictionary<String, AnyObject>]()
    var bookingID                                   = String()
    var phone_number                                = ""
    var isFromNotification                          = false
    var isBookingCancel                             = false
    var isFromIntitalLoad                           = false
    var cleintID                                    = String()
    var  bookingIDFromNoti                          = ""
    var clientLatt                                  = ""
    var clientLong                                  = ""
    var isFromCancelBooking                         = true
    var bookingComplete                             = false
    var completeBookingTosend                       = false
    
    //MARK:- =============Viewlife Cycle Methods==============================
    override func viewDidLoad() {
        super.viewDidLoad()
        setShadowview(newView: tableView)
        setShadowview(newView: locationView)
        if isFromNotification{
            self.callApiForbookingDetail()
        } else {
            self.callApiForbookingDetail()
            isFromIntitalLoad = true
            self.initialMethod()
        }
        NotificationCenter.default.addObserver(self, selector: #selector(chatDismiss), name: NSNotification.Name(rawValue: "dismissAppointment"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(reloadApi(notification: )), name: NSNotification.Name(rawValue: "reloadApi"), object: nil)
        APPDELEGATE.isAppointmentOnTop = true
        APPDELEGATE.threadId = upcommingInfo.bookingID
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        self.startBookingBtn.isHidden = false
        self.cancelBookingBtn.isHidden = false
        self.contactBtn.isHidden = false
        self.Arrow2Image.isHidden = false
        self.arrow3Image.isHidden = false
        self.moreImageView.isHidden = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if completeBookingTosend{
            self.startBookingBtn.isHidden = true
            self.contactBtn.isHidden = true
            self.cancelBookingBtn.isHidden = true
        }
    }
    
    @objc func chatDismiss() {
        self.view.endEditing(true)
        APPDELEGATE.threadId = ""
        APPDELEGATE.isAppointmentOnTop = false
        self.dismiss(animated: false, completion: nil)
    }
    
    /*
     Initial Method
     */
    func initialMethod()  {
        self.getAddressFromLatLon(pdblLatitude: Double(upcommingInfo.bookingLatitude)!, withLongitude: Double(upcommingInfo.bookingLongitude)!)
        self.detailsTexTView.text = upcommingInfo.bookingDescription == "" ? "No additional information " : upcommingInfo.bookingDescription
        self.contactBtn.setTitle("Contact \(upcommingInfo.clientFirstName)", for: .normal)
        self.clientName.text = upcommingInfo.clientFirstName + " " +  upcommingInfo.clientLastName
        self.clientTime.text = upcommingInfo.bookingTime
        self.clientImageView.sd_setImage(with:URL(string: upcommingInfo.clientImage ) , placeholderImage: UIImage(named: "profile_default") , options: .refreshCached)
        self.tableView.tableHeaderView = BackGroundView
        bookingID = upcommingInfo.bookingID
        cleintID = upcommingInfo.clientID
        if(upcommingInfo.bookingDate == getFormatStringFromDate(date: Date())){
            self.clientTime.text = "Today @ \(upcommingInfo.bookingTime)"
        }else if(upcommingInfo.bookingDate == getFormatStringFromDate(date:Date().addingTimeInterval(24 * 60 * 60))){
            self.clientTime.text = "Tomorrow @ \(upcommingInfo.bookingTime)"
        }else{
            self.clientTime.text = "\(upcommingInfo.bookingDate) @ \(upcommingInfo.bookingTime)"
        }
        NotificationCenter.default.addObserver(self, selector: #selector(chatDismiss), name: NSNotification.Name(rawValue: "UserDismiss"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(chatNotificationMethod(notification: )), name: NSNotification.Name(rawValue: "AppointmentNotification"), object: nil)
    }
    
    @objc func chatNotificationMethod(notification: Notification)  {
        if let info = notification.userInfo as? Dictionary<String,String> {
            let ObjVC = UIStoryboard.init(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGChatViewController") as! BGChatViewController
            ObjVC.modalPresentationStyle = .overCurrentContext
            ObjVC.modalTransitionStyle = .coverVertical
            ObjVC.bookingID = info["msgBkId"]!
            ObjVC.cleintID = info["msgClId"]!
            ObjVC.artistID = info["msgArId"]!
            let vc = self.navigationController?.topViewController
            vc?.present(ObjVC, animated: false, completion: nil)
        }
    }
    
    @objc func reloadApi(notification: Notification)  {
        if let info = notification.userInfo as? Dictionary<String,String> {
            upcommingInfo.bookingID = info["msgClId"]!
            self.callApiForbookingDetail()
        }
    }
    
    //MARK:- =============UIButtonAction Methods==============================
    @IBAction func dismissButtonAction(_ sender: UIButton) {
        NotificationCenter.default.post(name: Notification.Name("dissmissBooking"), object: nil)
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func startBookingAction(_ sender: Any) {
        self.isFromCancelBooking = false
        if startBookingBtn.title(for: .normal) == "Complete Booking"{
            bookingComplete = true
        }else{
            bookingComplete = false
        }
        self.callApiForFetchStartBookingBooking()
    }
    
    @IBAction func contactAction(_ sender: UIButton) {
        let actionSheet = UIActionSheet(title: "", delegate: self, cancelButtonTitle: "Cancel", destructiveButtonTitle: nil, otherButtonTitles: "Send a Message","Call" )
        actionSheet.show(in: self.view)
    }
    
    @IBAction func cancelBookingAction(_ sender: Any) {
        AlertController.alert(title: "", message: "Are you sure to cancel this booking?", buttons: ["Cancel","Ok"]) { (alert, i) in
            if i == 1{
                self.isFromCancelBooking = true
                self.bookingComplete = false
                self.callApiForFetchStartBookingBooking()
            }
        }
    }
    
    //MARK:- =============Helper Methods==============================//
    func actionSheet(_ actionSheet: UIActionSheet, clickedButtonAt buttonIndex: Int){
        switch (buttonIndex){
        case 1:
            let ObjVC = UIStoryboard.init(name: "Main", bundle:nil).instantiateViewController(withIdentifier: "BGChatViewController") as! BGChatViewController
            ObjVC.modalPresentationStyle = .overCurrentContext
            ObjVC.modalTransitionStyle = .coverVertical
            ObjVC.bookingID = bookingID
            ObjVC.cleintID = cleintID
            ObjVC.isfromAppointment = true
            ObjVC.chatInfo = upcommingInfo
            self.present(ObjVC, animated: false, completion: nil)
            break
        case 2:
            if upcommingInfo.phone_Number != ""{
                let busPhone = upcommingInfo.phone_Number // To be replaced by phoone number of client.
                if let url = URL(string: "tel://\(busPhone)"), UIApplication.shared.canOpenURL(url) {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(url)
                    } else {
                        UIApplication.shared.openURL(url)
                    }
                }
            }else{
                AlertController.alert(title: "No contact number available .")
            }
            break
        default:
            break
        }
    }
    
    //MARK:- =============UIButton Actions==============================//
    /*
     Maps button action
     */
    @IBAction func openMapsButtonAction(_ sender: UIButton) {
        let destinationAddress = "\(upcommingInfo.bookingLatitude),\(upcommingInfo.bookingLongitude)"
        if UIApplication.shared.canOpenURL(URL(string: "comgooglemapsurl://")!) {
            let strMapUrl = "comgooglemaps://?saddr=Current%20Location&daddr=\(destinationAddress)&center=Current%20Location&directionsmode=driving"
            let strUrl = URL(string: strMapUrl)
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(strUrl!, options: [:], completionHandler: {(_ success: Bool) -> Void in
                })
            } else {
                // Fallback on earlier versions
            }
        } else {
            let addr = "http://maps.google.com/maps?daddr=\(destinationAddress)&saddr=Current%20Location"
            let url = URL(string: addr)
            UIApplication.shared.openURL(url!)
        }
    }
    
    //MARK:- Get address
    /*
     Method to fetch address from lattitude and longitude
     */
    func getAddressFromLatLon(pdblLatitude: Double, withLongitude pdblLongitude: Double){
        var center : CLLocationCoordinate2D = CLLocationCoordinate2D()
        let ceo: CLGeocoder                 = CLGeocoder()
        center.latitude                     = pdblLatitude
        center.longitude                    = pdblLongitude
        let loc: CLLocation                 = CLLocation(latitude:center.latitude, longitude: center.longitude)
        var addressString : String          = ""
        
        ceo.reverseGeocodeLocation(loc, completionHandler:
            {(placemarks, error) in
                if (error != nil){
                    print("reverse geodcode fail: \(error!.localizedDescription)")
                }
                if APPDELEGATE.isReachable{
                    let pm = placemarks! as [CLPlacemark]
                    if pm.count > 0 {
                        
                        let pm = placemarks![0]
                        if pm.subLocality != nil{
                            addressString = addressString + pm.subLocality! + ", "
                        }
                        if pm.thoroughfare != nil{
                            addressString = addressString + pm.thoroughfare! + ", "
                        }
                        if pm.locality != nil{
                            addressString = addressString + pm.locality! + ", "
                        }
                        if pm.country != nil {
                            addressString = addressString + pm.country! + ", "
                        }
                        if pm.postalCode != nil {
                            addressString = addressString + pm.postalCode! + " "
                        }
                        self.clientLocation.text = addressString
                    }
                }else{
                    
                }
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK:- Webservice Method
    func callApiForFetchStartBookingBooking() {
        let localApiName = bookingComplete ? "completeBooking" :  isFromCancelBooking ? "cancelBooking" :kAPIStartBooking
        let dict = NSMutableDictionary()
        dict[pBookingID] = upcommingInfo.bookingID
        if bookingComplete {
            dict[pUserType] = "client"
            completeBookingTosend = true
        } else if isFromCancelBooking {
            dict[pUserType] = "client"
        }
        ServiceHelper.request(params: dict as! Dictionary<String, AnyObject>, method: .post, apiName: localApiName, hudType: .simple) { (result, error, status) in
            if (error == nil) {
                if let response = result as? Dictionary<String, AnyObject> {
                    if(response.validatedValue(pStatus, expected:"" as AnyObject)).boolValue{
                        self.bookingComplete = true
                        if localApiName == kAPIStartBooking{
                            self.cancelBookingBtn.isHidden = true
                            self.arrow3Constraint.constant = 8
                            self.completeBookingTopConstraint.constant = 3
                            self.Arrow2Image.isHidden = true
                        }else{
                            self.cancelBookingBtn.isHidden = true
                            self.completeBookingTopConstraint.constant = 27
                            self.arrow3Constraint.constant = 8
                            self.Arrow2Image.isHidden = false
                        }
                        self.startBookingBtn.setTitle("Complete Booking", for: .normal)
                        AlertController.alert(title: "", message:response.validatedValue("message", expected: "" as AnyObject) as! String)
                        NotificationCenter.default.post(name: Notification.Name("dissmissBooking"), object: nil)
                        if localApiName == "completeBooking"
                        {
                            self.navigationController?.popViewController(animated: false)
                            self.dismiss(animated: false, completion: nil)
                            
                        }else if self.isFromCancelBooking{
                            self.dismiss(animated: false, completion: nil)
                        }
                    }
                }
                else {
                    _ = AlertController.alert(title: "", message: "Something went wrong.")
                }
            }
        }
    }
    
    func callApiForbookingDetail() {
        let localApiName = "bookingDetail"
        let dict = NSMutableDictionary()
        dict[pBookingID] = bookingIDFromNoti != "" ? bookingIDFromNoti : upcommingInfo.bookingID
        
        ServiceHelper.request(params: dict as! Dictionary<String, AnyObject>, method: .post, apiName: localApiName, hudType: .simple) { (result, error, status) in
            if (error == nil) {
                if let response = result as? Dictionary<String, AnyObject> {
                    if(response.validatedValue(pStatus, expected:"" as AnyObject)).boolValue{
                        let dataArray : Array<Dictionary<String, AnyObject>> = response.validatedValue("data", expected: Array<Dictionary<String, AnyObject>>() as AnyObject) as! Array<Dictionary<String, AnyObject>>
                        self.upcommingInfo = BGUpcomingInfoModel.getBookingList(list: dataArray)
                        if !self.isFromCancelBooking{
                            if self.upcommingInfo.bookingStatus == "cancel"{
                                AlertController.alert(title: "Your Appointment has been cancelled.")
                                self.dismiss(animated: false, completion: nil)
                            }
                        }else if self.isFromIntitalLoad{
                            if self.upcommingInfo.bookingStatus == "start"{
                                self.startBookingBtn.setTitle("Complete Booking", for: .normal)
                                self.cancelBookingBtn.isHidden = true
                                self.completeBookingTopConstraint.constant = 3
                                self.arrow3Constraint.constant = 8
                                self.Arrow2Image.isHidden = true
                                self.bookingComplete = true
                            }else{
                                self.startBookingBtn.setTitle("Start Booking", for: .normal)
                                self.cancelBookingBtn.isHidden = false
                                self.completeBookingTopConstraint.constant = 27
                                self.arrow3Constraint.constant = 30
                                
                                self.Arrow2Image.isHidden = false
                                self.bookingComplete = false
                            }
                        } else {
                            self.startBookingBtn.isHidden = true
                            self.cancelBookingBtn.isHidden = true
                            self.contactBtn.isHidden = true
                            self.Arrow2Image.isHidden = true
                            self.arrow3Image.isHidden = true
                            self.moreImageView.isHidden = true
                        }
                        self.initialMethod()
                    }
                }
                else {
                    _ = AlertController.alert(title: "", message: "Something went wrong.")
                }
            }
        }
    }
}

