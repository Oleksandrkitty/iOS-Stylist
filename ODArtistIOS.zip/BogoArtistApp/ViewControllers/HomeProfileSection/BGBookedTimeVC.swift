//
//  BGBookedTimeVC.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 12/28/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class BGBookedTimeVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var timeContainerView     : UIView!
    @IBOutlet var containerView         : UIView!
    @IBOutlet var tableView             : UITableView!
    @IBOutlet var dayLabel              : UILabel!
    @IBOutlet var timeLabel             : UILabel!
    @IBOutlet var monthNameLabel        : UILabel!
    var monthname                       = ""
    var dayname                         = ""
    var dateNumber                      = ""
    var slotString                      = ""
    var bookedSlotString                = ""
    var fullDateString                  = ""
    var timeSlotArray                   = ["12-13 pm","13-14 pm","14-15 pm","15-16 pm","16-17 pm","17-18 pm","18-19 pm","19-20 pm","20-21 pm","21-22 pm","22-23 pm","23-24 pm","24-1 am","1-2 am","2-3 am","3-4 am","4-5 am","5-6 am","6-7 am","7-8 am","8-9 am","9-10 am","10-11 am","11-12 pm"]
    var scheduledTimeArray              = [String]()
    var scheduledRemoveTimeArray        = [String]()
    var bookedSlotArray                 = [String]()
    var indexArray                      = [String]()
   
    // MARK:- ============ View life cycle Methods ==============//
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dayLabel.text = dayname
        self.timeLabel.text = dateNumber
        self.monthNameLabel.text = monthname
        self.monthNameLabel.text = monthname.subStringWithRange(0, end: 3)
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: Notification.Name("PostForDismiss"), object: nil)
        bookedSlotArray  = bookedSlotString.components(separatedBy: ",")
        if slotString == ""{
            
        }else{
            var sortedArray = [Int]()
            var tempArray :[String] = slotString.components(separatedBy: ",")
            for item in bookedSlotArray{
                if !tempArray.contains(item){
                    tempArray.append(item)
                }
            }
            for item in tempArray{
                if item != ""{
                    let intValue = Int(item)
                    sortedArray.append(intValue!)
                }
                
            }
            let arrayTobeSorted = sortedArray.sorted()
            for itemTemp in arrayTobeSorted{
                let stringValue = String(itemTemp)
                self.scheduledTimeArray.append(stringValue)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func methodOfReceivedNotification(notification: Notification){
        self.dismiss(animated: false, completion: nil)
    }
    
    // MARK:- ============ UITableView DataSource Methods ==============//
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  scheduledTimeArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: BGBookedTimeCell = tableView.dequeueReusableCell(withIdentifier: "BGBookedTimeCell", for: indexPath) as! BGBookedTimeCell
        cell.crossAction.tag = indexPath.row + 10
        cell.crossAction.addTarget(self, action: #selector(cancelBooking(_:)), for: .touchUpInside)
        if scheduledTimeArray.count > 0{
            var newIndex : Int = Int(scheduledTimeArray[indexPath.row])!
            if newIndex >= 12{
                if bookedSlotArray.contains("\(newIndex)"){
                    cell.containerView.backgroundColor = #colorLiteral(red: 0.3071894348, green: 0.8093062043, blue: 0.7460683584, alpha: 1)
                    cell.crossAction.isHidden = true
                    cell.timeLabel.textColor = UIColor.white
                    cell.timeLabel.text = ((String(newIndex - 12) == "0") ? "12 - 1 PM":( String(newIndex - 12) + " - " + String((newIndex - 12) + 1) + " PM" + " ")) + "  Booked!"
                }else{
                    cell.containerView.backgroundColor = UIColor.white
                    cell.crossAction.isHidden = false
                    cell.timeLabel.textColor = UIColor.black
                    cell.timeLabel.text = (String(newIndex - 12) == "0" ? "12 - 1 ": String(newIndex - 12) + " - " + String((newIndex - 12) + 1)) + " PM"
                }
            }else{
                var suffixDate = ""
                if newIndex + 1 == 12{
                    suffixDate = " PM"
                }else {
                    suffixDate = " AM"
                }
                
                if bookedSlotArray.contains("\(newIndex)"){
                    cell.containerView.backgroundColor = #colorLiteral(red: 0.3071894348, green: 0.8093062043, blue: 0.7460683584, alpha: 1)
                    cell.crossAction.isHidden = true
                    cell.timeLabel.textColor = UIColor.white
                    if newIndex == 0 {
                        newIndex = 12
                        suffixDate = "AM"
                    }
                    if newIndex == 12 {
                        cell.timeLabel.text = String(newIndex) + " - " + String(1) + suffixDate +  " " + " Booked!"
                    }else {
                        cell.timeLabel.text = String(newIndex) + " - " + String(newIndex + 1) + suffixDate +  " " + " Booked!"
                    }
                }else{
                    cell.containerView.backgroundColor = UIColor.white
                    cell.crossAction.isHidden = false
                    if newIndex == 12 {
                        cell.timeLabel.text = String(newIndex) + " - " + String(1) + suffixDate
                    }else{
                        cell.timeLabel.text = String(newIndex) + " - " + String(newIndex + 1) + suffixDate

                    }
                    cell.timeLabel.textColor = UIColor.black
                }
            }
            cell.crossAction.setImage(UIImage.init(named: "crossGrey"), for: .normal)
        }else{
            return cell
        }
        return cell
    }
    
    // MARK:- ============ UITableView Delegate Methods ==============//
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 44.0
    }
    
    // MARK:- ============ UIButton Action Methods ==============//
    @IBAction func crossAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
   
    @objc func cancelBooking(_ sender: UIButton) {
        let deletedSlot = self.scheduledTimeArray[(sender.tag - 10)]
        self.scheduledRemoveTimeArray.append(deletedSlot)
        self.scheduledTimeArray.remove(at: sender.tag - 10)
        self.callApiForPostArtistSchedule()
        self.tableView.reloadData()
    }
    
    @IBAction func addScheduleAction(_ sender: UIButton) {
        let bookingDetailVC = storyBoardForName(name: "Main").instantiateViewController(withIdentifier: "BGBookedScheduleVC") as! BGBookedScheduleVC
        bookingDetailVC.dateFullToSend = fullDateString
        bookingDetailVC.slectedMonth = self.monthname.subStringWithRange(0, end: 3)
        bookingDetailVC.selectedDay = self.dayname
        bookingDetailVC.slectedDAte   = self.dateNumber
        bookingDetailVC.slotArray = self.scheduledTimeArray
        bookingDetailVC.modalPresentationStyle = .overFullScreen
        bookingDetailVC.modalTransitionStyle = .coverVertical
        self.navigationController?.present(bookingDetailVC, animated: false, completion: nil)
    }
   
    //MARK:- WebService Method
    func callApiForPostArtistSchedule() {
        let dict = NSMutableDictionary()
        dict[pArtistID] = USERDEFAULT.value(forKey: pArtistID)
        dict[pDate] = fullDateString //scheduleObject.current_Month
        dict[pSlot] = self.scheduledRemoveTimeArray //scheduleObject.current_CurrentYear
        
        ServiceHelper.request(params: dict as! Dictionary<String, AnyObject>, method: .post, apiName: kDeleteArtistSchedule, hudType: .simple) { (result, error, status) in
            
            if (error == nil) {
                
                if let response = result as? Dictionary<String, AnyObject> {
                    let slotArryaTosend:[String: String] = ["array": self.fullDateString]
                    AlertController.alert(title: "", message: response.validatedValue("message", expected: "" as AnyObject) as! String, buttons: ["Ok"], tapBlock: { (alert, i) in
                        if i == 0{
                            self.dismiss(animated: true, completion: nil)
                        }
                    })
                    NotificationCenter.default.post(name: Notification.Name("PostForSchedule"), object: nil ,userInfo: slotArryaTosend)
                }
            }
            else {
                _ = AlertController.alert(title: "", message: "\(error!.localizedDescription)")
                
            }
        }
    }
}
