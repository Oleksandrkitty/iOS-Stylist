//
//  BGSchduleVC.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 12/27/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit
import CVCalendar

class BGSchduleVC: UIViewController,CVCalendarViewDelegate,CVCalendarMenuViewDelegate,CVCalendarViewAppearanceDelegate {
    struct Color {
        static let selectedText         = UIColor.red
        static let text                 = UIColor.white
        static let textDisabled         = UIColor.gray
        static let selectionBackground  = UIColor.white
        static let sundayText           = UIColor.white
        static let sundayTextDisabled   = UIColor(red: 1.0, green: 0.6, blue: 0.6, alpha: 1.0)
        static let sundaySelectionBackground = sundayText
    }
    
 //Calendarview outlet For Weekdays and monthdays
    @IBOutlet var menuView                  : CVCalendarMenuView!
    @IBOutlet var calendarView              : CVCalendarView!
    @IBOutlet weak var currentYearMonthDAte : UILabel!
    
    //Local Navigationcontroller Outlet
    var newNavigationController             : UINavigationController!
    var startDateOne                        = Date()
    var schedulearray                       = [BGScheduleModel]()
    
    var dateArray                           = [String]()
    var isFromeFirstTime                    = 0
    var scheduleObject                      = BGScheduleModel()
    var slotDaysDictionary                  =  NSMutableDictionary()
    var bookedSlotDict                      = NSMutableDictionary()
    var currentCalendar                     : Calendar?

    //MARK:->=================View Lifecycle Methods=======================>
    override func viewDidLoad() {
        super.viewDidLoad()
        let currentDate = Date()
        let calendar = Calendar.current
        let year = calendar.component(.year, from: currentDate)
        let month = calendar.component(.month, from: currentDate)
        scheduleObject.current_Month = String(month)
        scheduleObject.current_CurrentYear = String(year)
        
        let timeZoneBias = 480 // (UTC+08:00)
        currentCalendar = Calendar.init(identifier: .gregorian)
        currentCalendar?.locale = Locale(identifier: "fr_FR")
        if let timeZone = TimeZone.init(secondsFromGMT: -timeZoneBias * 60) {
            currentCalendar?.timeZone = timeZone
        }
        isFromeFirstTime = 2
        
        self.setupDefault()
        NotificationCenter.default.addObserver(self, selector: #selector(self.showSpinningWheel(_:)), name: NSNotification.Name(rawValue: "PostForSchedule"), object: nil)
        
        // handle notification
        if let currentCalendar = currentCalendar {
            currentYearMonthDAte.text = CVDate(date: Date(), calendar: currentCalendar).globalDescription
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.callApiForGetArtistSchedule()
        MBProgressHUD.showAdded(to: APPDELEGATE.window!, animated: true)
        delay(delay: 5) {
            self.calendarView.contentController.refreshPresentedMonth()
            MBProgressHUD.hide(for: APPDELEGATE.window!, animated: true)
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Commit frames' updates
        self.menuView.commitMenuViewUpdate()
        self.calendarView.commitCalendarViewUpdate()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    @objc func showSpinningWheel(_ notification: NSNotification) {
       self.callApiForGetArtistSchedule()
        MBProgressHUD.showAdded(to: APPDELEGATE.window!, animated: true)
        delay(delay: 5) {
            self.calendarView.contentController.refreshPresentedMonth()
            MBProgressHUD.hide(for: APPDELEGATE.window!, animated: true)
        }
    }
   
    //Default Setup Methods
    func setupDefault(){
        // Appearance delegate [Unnecessary]
        self.calendarView.calendarAppearanceDelegate = self
        // Animator delegate [Unnecessary]
        self.calendarView.animatorDelegate = self
        // Menu delegate [Required]
        self.menuView.menuViewDelegate = self
        // Calendar delegate [Required]
        self.calendarView.calendarDelegate = self
    }
    
    func didShowNextMonthView(_ date: Foundation.Date){
    }
    
    func didShowPreviousMonthView(_ date: Foundation.Date){

    }
    
    //MARK:- =======================>CalenderDelegate Methods<====================//
    func shouldSelectDayView(_ dayView: DayView) -> Bool{
        return true
    }

    func shouldAutoSelectDayOnMonthChange() -> Bool{
        return true
    }
    
    @objc func didSelectDayView(_ dayView: DayView, animationDidFinish: Bool){
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let dayYearString = dateFormatter.string(from: dayView.date.date)
        let currentDay = getDaynameUsingDate(index: dayView.weekdayIndex)
        if isFromeFirstTime == 2{

        }else if (dayView.date.convertedDate()! < self.startDateOne) && (!dayView.isCurrentDay){
            AlertController.alert(message: "Please select future date. ")
        }else{
            let bookingDetailVC = storyBoardForName(name: "Main").instantiateViewController(withIdentifier: "BGBookedTimeVC") as! BGBookedTimeVC
            if (dayView.date != nil){
                
                for  eventDate in dateArray{
                    let event = String(eventDate)
                    if dayYearString == event  {
                        bookingDetailVC.slotString =  self.slotDaysDictionary.value(forKey: eventDate) as! String
                        bookingDetailVC.bookedSlotString = self.bookedSlotDict.value(forKey: eventDate) as! String
                    }
                }
            }
            var monthArray = [String]()
            monthArray =  dayView.date.commonDescription.components(separatedBy: " ")
            bookingDetailVC.monthname = monthArray[1].uppercased()
            bookingDetailVC.dayname = currentDay.uppercased()
            bookingDetailVC.fullDateString = dayYearString
            bookingDetailVC.dateNumber = String(dayView.date.day)
            self.newNavigationController = UINavigationController.init(rootViewController: bookingDetailVC)
            self.newNavigationController.modalPresentationStyle = .overCurrentContext
            self.newNavigationController.modalTransitionStyle = .coverVertical
            self.newNavigationController.isNavigationBarHidden = true
            self.navigationController?.present(newNavigationController, animated: false, completion: nil)
        }
        isFromeFirstTime = 0
        
    }
    
    //MARK:- ========>Animation Calendar Methods <=========
    @objc func presentedDateUpdated(_ date: CVDate){
        scheduleObject.current_Month = String(date.month)
        
        if (date.convertedDate()! < self.startDateOne) {
            // AlertController.alert(message: "Scheduling can not possible in past days ")
        }else{
            self.callApiForGetArtistSchedule()
            MBProgressHUD.showAdded(to: APPDELEGATE.window!, animated: true)
            delay(delay: 5) {
                self.calendarView.contentController.refreshPresentedMonth()
                MBProgressHUD.hide(for: APPDELEGATE.window!, animated: true)
            }
        }
        
        if currentYearMonthDAte.text != date.globalDescription {
            let updatedMonthLabel = UILabel()
            updatedMonthLabel.textColor = currentYearMonthDAte.textColor
            updatedMonthLabel.font = currentYearMonthDAte.font
            updatedMonthLabel.textAlignment = .center
            updatedMonthLabel.text = date.globalDescription
            updatedMonthLabel.sizeToFit()
            updatedMonthLabel.alpha = 0
            updatedMonthLabel.center = self.currentYearMonthDAte.center
            
            let offset = CGFloat(48)
            updatedMonthLabel.transform = CGAffineTransform(translationX: 0, y: offset)
            updatedMonthLabel.transform = CGAffineTransform(scaleX: 1, y: 0.1)
            
            UIView.animate(withDuration: 0.35, delay: 0, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.currentYearMonthDAte.transform = CGAffineTransform(translationX: 0, y: -offset)
                self.currentYearMonthDAte.transform = CGAffineTransform(scaleX: 1, y: 0.1)
                self.currentYearMonthDAte.alpha = 0
                
                updatedMonthLabel.alpha = 1
                updatedMonthLabel.transform = CGAffineTransform.identity
                
            }) { _ in
                
                self.currentYearMonthDAte.frame = updatedMonthLabel.frame
                self.currentYearMonthDAte.text = updatedMonthLabel.text
                self.currentYearMonthDAte.transform = CGAffineTransform.identity
                self.currentYearMonthDAte.alpha = 1
                updatedMonthLabel.removeFromSuperview()
            }
            isFromeFirstTime = 2
            self.view.insertSubview(updatedMonthLabel, aboveSubview: self.currentYearMonthDAte)
        }
    }
    
    func dayOfWeekTextColor(by weekday: Weekday) -> UIColor {
        return .white
    }
    
    func presentationMode() -> CalendarMode {
        return .monthView
    }
    
    func firstWeekday() -> Weekday {
        return .sunday
    }
    
    func disableScrollingBeyondDate() -> Date{
      return Date()
    }
    
    func shouldScrollOnOutDayViewSelection() -> Bool {
        return false
    }

    func preliminaryView(viewOnDayView dayView: DayView) -> UIView {
        let circleView = CVAuxiliaryView(dayView: dayView, rect: dayView.frame, shape: CVShape.circle)
        circleView.fillColor = UIColor.red
        
        return circleView
    }
    
    func preliminaryView(shouldDisplayOnDayView dayView: DayView) -> Bool {
        if (dayView.isCurrentDay) {
            return true
        }
        return false
    }
    
    func dayLabelFont(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIFont { return UIFont.systemFont(ofSize: 14) }
    
    func dayLabelColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (_, .selected, _), (_, .highlighted, _): return UIColor.white
        case (.sunday, .in, _): return Color.sundayText
        case (.sunday, _, _): return Color.sundayTextDisabled
        case (_, .in, _): return Color.text
        default: return Color.textDisabled
        }
    }
    
    func dayLabelBackgroundColor(by weekDay: Weekday, status: CVStatus, present: CVPresent) -> UIColor? {
        switch (weekDay, status, present) {
        case (.sunday, .selected, _), (.sunday, .highlighted, _): return Color.sundaySelectionBackground
        case (_, .selected, _), (_, .highlighted, _): return UIColor.clear
        default: return nil
        }
    }

    func topMarker(shouldDisplayOnDayView dayView: DayView) -> Bool{

        if (dayView.date != nil){
            if (dayView.date.convertedDate()! < self.startDateOne && !dayView.isCurrentDay){
                return false
            }else{
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let str = dateFormatter.string(from: dayView.date.date)
                for eventDate in dateArray{
                    let event = String(eventDate)
                    if str == event  {
                        return true
                    }
                }
                return false
            }
        }else{
            return false
        }
    }
    
    //MARK:- WebService Method
 /*
     Call service for event Creation*/
    func callApiForGetArtistSchedule() {
        
        let dict = NSMutableDictionary()
        dict[pArtistID] = USERDEFAULT.value(forKey: pArtistID)
        dict[pMonth] = scheduleObject.current_Month
        dict[pYear] = scheduleObject.current_CurrentYear
        
        ServiceHelper.request(params: dict as! Dictionary<String, AnyObject>, method: .post, apiName: kGetArtistSchedule, hudType: .smoothProgress) { (result, error, status) in
            
            if (error == nil) {
                if let response = result as? Dictionary<String, AnyObject> {
                    let messageStatus = response.validatedValue(kMessageSchedule, expected: "" as AnyObject)
                    if messageStatus as! String == pMeassagestatus{
                        AlertController.alert(message: pMeassagestatus )
                    }else{
                        let dataArray = response.validatedValue(kDataSchedule, expected: [] as AnyObject)
                        
                        self.schedulearray = BGScheduleModel.getScheduleArray(responseArray: dataArray as! Array<Dictionary<String, String>>)
                        self.dateArray.removeAll()
                        for item in self.schedulearray{
                            let scheduleObject = item
                            self.slotDaysDictionary[scheduleObject.scheduleDate] = scheduleObject.slot
                            self.bookedSlotDict[scheduleObject.scheduleDate] = scheduleObject.bookedSlot
                            self.dateArray.append(scheduleObject.scheduleDate)
                        }
                        self.setupDefault()
                    }
                }
            }
            else {
                _ = AlertController.alert(title: "", message: "\(error!.localizedDescription)")
                
            }
        }
    }
}
