//
//  BGBookedScheduleVC.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 12/28/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class BGBookedScheduleVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {

    //UIViews Outlet
    @IBOutlet var containerView     : UIView!
    @IBOutlet var calenderView      : UIView!

    //UICollectionview Outlet
    @IBOutlet var collectionView    : UICollectionView!

    //Label for use in Calendar
    @IBOutlet var dayLabel          : UILabel!
    @IBOutlet var dateLabel         : UILabel!
    @IBOutlet var monthLabel        : UILabel!
    var slotString                  = ""
    var imageNamedString            = ""
    var dateFullToSend              = ""
    var slectedDAte                 = ""
    var selectedDay                 = ""
    var slectedMonth                = ""
    var indexSelect                 = 0
    var slotArray                   = [String]()
    var timeSlotArrayForModel       = ["12 ","1 ","2 ","3 ","4 ","5 ","6 ","7 ","8 ","9 ","10 ","11 ","24 ","13 ","14 ","15 ","16 ","17 ","18 ","19 ","20 ","21 ","22 ","23 "]
    var timeSlotArray               = NSMutableArray()
    var indexArray                  = [String]()
    var selecedtIndexArray          = [String]()

    
    //MARK:- ============>View life Cycle Methods<=============>>
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setDefault()
        self.dayLabel.text = selectedDay
        self.dateLabel.text = slectedDAte
        self.monthLabel.text = slectedMonth
        
        for var strTemp in self.slotArray {
            var indexNumber = 0
            if strTemp == "0" {
                strTemp = "12"
            }
            for str1Temp in timeSlotArrayForModel {
                let slotString = str1Temp
                let tempArray = (slotString as AnyObject).components(separatedBy: " ")
                if strTemp == tempArray[0] {
                    indexArray.append("\(indexNumber)")
                }
                indexNumber += 1
            }
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func setDefault() {
        for item in timeSlotArrayForModel{
            timeSlotArray.add(BGScheduleModel.setField(text: item, selected: false))
        }
    }
    
    //MARK:- ============>UICollectionView Datasource Methods<=============>>
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return timeSlotArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BGScheduleCell", for: indexPath) as! BGScheduleCell
        let obj = timeSlotArray.object(at: indexPath.row) as! BGScheduleModel
        cell.timeImageView.tag = indexPath.row
        cell.TimeLabel.tag = indexPath.row
        if indexArray.contains("\(indexPath.row)") {
            cell.timeSlotLabel.isHidden = true
            cell.TimeLabel.text = obj.slotNumber
            cell.TimeLabel.textColor = UIColor.white
            cell.timeImageView.image = UIImage.init(named: "avalible")
            cell.timeContainerView.backgroundColor = UIColor.init(red: 78.0/255.0, green: 206.0/255.0, blue: 190.0/255.0, alpha: 1)
        }else{
            cell.timeContainerView.tag = indexPath.row
            cell.timeSlotLabel.isHidden = true
            cell.TimeLabel.text = obj.slotNumber
            cell.TimeLabel.textColor =  obj.isSlotSelected ? UIColor.white : UIColor.gray
            cell.timeImageView.image = !obj.isSlotSelected ? UIImage.init(named: "watch") : UIImage.init(named: "avalible")
            cell.timeContainerView.backgroundColor = !obj.isSlotSelected ? UIColor.init(red: 235.0/255.0, green: 235.0/255.0, blue: 235.0/255.0, alpha: 1) :  UIColor.init(red: 78.0/255.0, green: 206.0/255.0, blue: 190.0/255.0, alpha: 1)
        }
        
        return cell
    }
    
    // MARK: - UICollectionViewDelegate Protocols >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: IndexPath) -> CGSize {
        return collectionView.frame.size
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let obj = timeSlotArray.object(at: indexPath.row) as! BGScheduleModel
        obj.isSlotSelected = !obj.isSlotSelected
        if obj.isSlotSelected{
            
            if obj.slotNumber.contains("AM") {
                let numberObj = obj.slotNumber.easternArabicNumeralsOnly
                self.slotArray.append(numberObj)
            }else {
                let numberObj = obj.slotNumber.easternArabicNumeralsOnly
                
                self.slotArray.append("\(Int(numberObj)! + 12)")
            }
        }
        else{
            if slotArray.contains(indexPath.row){
                self.slotArray.remove(at: indexPath.row)
            }
        }
        self.collectionView.reloadData()
    }
   
    //MARK:- =====================>UIButton Action Methods<=================//
    @IBAction func scheduleAction(_ sender: UIButton) {
        self.callApiForPostArtistSchedule()
    }
    
    @IBAction func crossAction(_ sender: UIButton) {
        self.dismiss(animated: false) {
        }
    }
   
    //MARK:- WebService Method
    func callApiForPostArtistSchedule() {
        let dict = NSMutableDictionary()
        dict[pArtistID] = USERDEFAULT.value(forKey: pArtistID)
        dict[pDate] = dateFullToSend //scheduleObject.current_Month
        dict[pSlot] = self.slotArray //scheduleObject.current_CurrentYear
        
        ServiceHelper.request(params: dict as! Dictionary<String, AnyObject>, method: .post, apiName: kPostArtistSchedule, hudType: .simple) { (result, error, status) in
            if (error == nil) {
                if let response = result as? Dictionary<String, AnyObject> {
                    let slotArryaTosend:[String: String] = ["array": self.dateFullToSend]
                    print(response)
                    NotificationCenter.default.post(name: Notification.Name("PostForSchedule"), object: nil ,userInfo: slotArryaTosend)
                    
                    let bookingDetailVC = storyBoardForName(name: "Main").instantiateViewController(withIdentifier: "BGBookedTimeVC") as! BGBookedTimeVC
                    bookingDetailVC.monthname = self.slectedMonth.subStringWithRange(0, end: 3)
                    bookingDetailVC.dayname = self.selectedDay
                    bookingDetailVC.dateNumber  = self.slectedDAte
                    let combinedArray = self.slotArray + self.selecedtIndexArray
                    bookingDetailVC.scheduledTimeArray = combinedArray
                    
                    self.dismiss(animated: false, completion: nil)
                    NotificationCenter.default.post(name: Notification.Name("PostForDismiss"), object: nil)
                }
            }
            else {
                _ = AlertController.alert(title: "", message: "\(error!.localizedDescription)")
            }
        }
    }
}

extension String {
    var easternArabicNumeralsOnly: String {
        let pattern = UnicodeScalar("0")..."9"
        return String(unicodeScalars
            .flatMap { pattern ~= $0 ? Character($0) : nil })
    }
}
