//
//  IndexPathButton.swift
//  Smoogin
//
//  Created by TheAppSmiths on 01/06/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class IndexPathButton: UIButton {

    var indexPath: IndexPath?

}
