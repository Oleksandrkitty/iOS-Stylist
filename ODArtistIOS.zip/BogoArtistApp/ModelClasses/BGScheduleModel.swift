//
//  BGScheduleModel.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 1/4/18.
//  Copyright © 2018 TheAppSmiths. All rights reserved.
//

import UIKit

class BGScheduleModel: NSObject {

    var current_Month           = ""
    var current_CurrentYear     = ""
    var slot                    = ""
    var bookedSlot              = ""
    var slotArray               = [Int]()
    var scheduleDate            = ""
    var slotNumber              = ""
    var isSlotSelected          = false
    
    class func getScheduleArray(responseArray : Array<Dictionary<String, String>>) -> Array<BGScheduleModel> {
        var newsItemsArray = Array<BGScheduleModel>()
        for newsItem in responseArray {
            let newsItemsObj = BGScheduleModel()
            newsItemsObj.scheduleDate = newsItem[pScheduledate]!
            newsItemsObj.slot = newsItem[pSlot]!
            newsItemsObj.bookedSlot = newsItem["booked_slot"]!
            newsItemsArray.append(newsItemsObj)
        }
        return newsItemsArray
    }
    class func setField(text: String,  selected:Bool) -> BGScheduleModel {
        let modal = BGScheduleModel()
        let newIndex : Int = Int(text.trimWhiteSpace)!
        if Int(newIndex) > 12{
            
            modal.slotNumber = (String(newIndex - 12) == "0" ? "12 " : String(newIndex - 12)) + " PM"
        }else if Int(newIndex) <= 12 {
            modal.slotNumber = String(newIndex) + " AM"

        }
        modal.isSlotSelected = selected
        return modal
    }
}
