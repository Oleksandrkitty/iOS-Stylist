//
//  BGProfileInfoModel.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 1/4/18.
//  Copyright © 2018 TheAppSmiths. All rights reserved.
//

import UIKit

class BGProfileInfoModel: NSObject {
  
}
