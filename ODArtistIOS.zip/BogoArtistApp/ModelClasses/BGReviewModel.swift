//
//  BGReviewModel.swift
//  BogoArtistApp
//
//  Created by TheAppSmiths on 01/02/18.
//  Copyright © 2018 TheAppSmiths. All rights reserved.
//

import UIKit

class BGReviewModel: NSObject {

}
