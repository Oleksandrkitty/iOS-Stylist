//
//  LocationInfo.swift
//  BazaarCart
//
//  Created by TheAppSmiths on 06/10/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class LocationInfo: NSObject {
    var street                  = ""
    var subLocality             = ""
    var subAdministrativeArea   = ""
    var city                    = ""
    var state                   = ""
    var country                 = ""
    var postalCode              = ""
    var address                 = ""
    var lat                     = ""
    var long                    = ""
}
