//
//  CQUser.swift
//  CabQ
//
//  Created by TheAppSmiths on 11/09/17.
//  Copyright © 2017 TheAppSmiths. All rights reserved.
//

import UIKit

class CQUser: NSObject {
    
    var userId          = ""
    var name            = ""
    var email           = ""
    var password        = ""
    var mobileNo        = ""
    var gender          = ""
    var dob             = ""
    var firstName       = ""
    var lastName        = ""
    
    class func user(_ infoDict: Dictionary<String, AnyObject>?) -> CQUser {
        let info = CQUser()
        if let userDict = infoDict {
            info.userId = "\(userDict.validatedValue("key", expected: "" as AnyObject))"
            info.name = "\(userDict.validatedValue("key", expected: "" as AnyObject))"
            info.email = "\(userDict.validatedValue("email", expected: "" as AnyObject))"
        }
        return info
    }
}
